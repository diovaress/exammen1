
public class principal {

   
    public static void main(String[] args) {
       
        registro inst = new registro();
        inst.setLocationRelativeTo(null);
        inst.show();
        
       
    }
    
}
